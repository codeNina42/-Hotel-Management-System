package Interface;
import Classes.*;

import java.lang.*;

public interface IOperations extends IEmployee, ICustomer, IRoom{
  
}
